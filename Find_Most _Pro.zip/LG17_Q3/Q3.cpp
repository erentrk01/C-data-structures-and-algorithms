/* LG17_Q3 -> Structure Linked List Question */

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include "linkedList_struct.h"

//function that creates the list by using the file elements
node_t* createList(FILE *inp);
//function that displays the list
void displayList(node_t *headp);
node_t * searchCommittee(node_t *headp, char srch[]);
node_t * findWinner(node_t * headp);

int main(void)
{
	FILE	*inp;
	node_t	*list,
		*p;
	char committee[SIZE];

	inp = fopen("Committee.txt", "r");
	if (inp == NULL)
		printf("File can not be opened!");
	else
	{
		list = createList(inp);
		fclose(inp);

		printf("List of ALL Staff\n");
		displayList(list);

		p = findWinner(list);
		printf("The Winner: ");
		printf("%s %s, %s, %d\n\n", p->data.name, p->data.surname, p->data.committee, p->data.numberOfJobs);

		printf("Enter a committee to search: ");
		scanf("%[^\n]s", committee);

		p = searchCommittee(list, committee);

		if (p == NULL)
			printf("\nThere NO committee such a %s !\n", committee);
		else
			printf("\n%s %s, %s, %d\n", p->data.name, p->data.surname, p->data.committee, p->data.numberOfJobs);
	}

	return 0;
}

node_t* createList(FILE *inp)
{
	node_t *headp, *p;
	int status;
	LType tmp;

	headp = NULL;

	status = fscanf(inp, "%s %s %s %d", tmp.name, tmp.surname, tmp.committee, &tmp.numberOfJobs);

	if (status != EOF)
	{
		headp = addBeginning(headp, tmp);

		status = fscanf(inp, "%s %s %s %d", tmp.name, tmp.surname, tmp.committee, &tmp.numberOfJobs);

		p = headp;
		while (status != EOF)
		{
			addAfter(p, tmp);
			p = p->next;
			status = fscanf(inp, "%s %s %s %d", tmp.name, tmp.surname, tmp.committee, &tmp.numberOfJobs);
		}
	}

	fclose(inp);

	return headp;
}

void displayList(node_t *hp)
{
	if (hp == NULL)
		printf("\nThe List is EMPTY !!!\n\n");
	else
	{
		printf("Name     Surname    Committee     #OfJobs\n");
		printf("******   ********   *********   ********\n");

		while (hp != NULL)
		{
			printf("%-8s %-8s   %-12s %5d ->\n", hp->data.name, hp->data.surname, hp->data.committee, hp->data.numberOfJobs);
			hp = hp->next;
		}
		printf("NULL\n\n");
	}
}

node_t * searchCommittee(node_t *headp, char srch[])
{
	node_t	*p;

	p = headp;
	while (p != NULL)
	{
		if (strcmp(p->data.committee, srch) == 0)
			return p;

		p = p->next;
	}

	return NULL;
}

node_t * findWinner(node_t * headp)
{
	node_t	*winner = headp,
		*p = headp->next;

	while (p != NULL)
	{
		if (p->data.numberOfJobs > winner->data.numberOfJobs)
			winner = p;

		p = p->next;
	}

	return winner;
}
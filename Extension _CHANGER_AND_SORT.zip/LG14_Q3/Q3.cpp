// Sorts the stack and changes all the extensions to the jpg
#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <string.h>
#include "stack_struct.h"

// sortes the stack and returns the sorted stack
stack_t sortStack(stack_t input);
//displays the stack content
void displayStack(stack_t st);
//finds the position of the '.' in a given string
int findDot(char *str);
// converts all the image extensions to the JPG
void convertJPG(stack_t *st);

int
main(void)
{
	FILE *inp;

	inp = fopen("images.txt", "r");
	if (inp == NULL)
		printf("FILE Can not be opened");
	else
	{
		stack_t st;
		initializeS(&st);
		SType temp;
		//getting file content into the stack
		while (fscanf(inp, "%s %d", temp.imageName, &temp.date) != EOF)
		{
			push(&st, temp);
		}
		//display the sorted stack and images with JPG extension
		printf("After Sort\n");
		printf("*******************\n");
		st = sortStack(st);
		displayStack(st);
		printf("After JPG Conversion\n");
		printf("*******************\n");
		convertJPG(&st);
		displayStack(st);
	}
	return 0;
}

stack_t sortStack(stack_t input)
{
	SType tmpInp;
	stack_t tmpStack;
	initializeS(&tmpStack);

	while (!isEmptyS(&input))
	{
		// pop out the first element
		tmpInp = pop(&input);

		while (!isEmptyS(&tmpStack) && tmpStack.data[tmpStack.top].date < tmpInp.date)
		{
			// pop from temporary stack and push
			// it to the input stack
			push(&input, pop(&tmpStack));
		}
		// push temp in temporary of stack
		push(&tmpStack, tmpInp);
	}
	return tmpStack;
}

void displayStack(stack_t st)
{
	SType temp;
	printf("Stack Content\n");
	while (!isEmptyS(&st))
	{
		temp = pop(&st);
		printf("%-15s %3d\n", temp.imageName, temp.date);
	}

}

int findDot(char *str)
{
	int i = 0;
	while (str[i] != '.')
		i++;
	return i;
}

void convertJPG(stack_t *st)
{
	SType tmp;
	stack_t tempSt;
	initializeS(&tempSt);
	char str[20] = "";
	int index;
	while (!isEmptyS(st))
	{
		tmp = pop(st);
		index = findDot(tmp.imageName);
		//if (strncmp(tmp.imageName + index, ".jpg", 4) != 0)
		strcpy(tmp.imageName + index, ".jpg");
		push(&tempSt, tmp);
	}
	*st = tempSt;
}
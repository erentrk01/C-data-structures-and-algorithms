

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include "queue_struct.h"

//read the info of cars from file
void readCarInfo(FILE *inp, queue_t *cars);
void displayCars(queue_t cars);
car_t findMinKM(queue_t *cars);

int main(void)
{
	FILE *inp = fopen("car.txt", "r");

	if (inp == NULL)
		printf("Error!!\n");
	else
	{
		int noOfCars;
		car_t temp;
		queue_t	cars;

		initializeQ(&cars);
		readCarInfo(inp, &cars);
		fclose(inp);
		displayCars(cars);

		//find and display the car which has got the minimum km
		temp = findMinKM(&cars);
		printf("\n\nCar with minimum km is %s %d",temp.plate,temp.km);
	}
}

void readCarInfo(FILE *inp, queue_t *cars)
{
	car_t temp;

	while (fscanf(inp, "%s%d", temp.plate, &temp.km) != EOF)
			insert(cars, temp);
}

void displayCars(queue_t cars)
{
	car_t temp;

	printf("\nThere are %d cars.\n", cars.counter);
	printf("*******************\n");

	while (!isEmptyQ(&cars))
	{
		temp = remove(&cars);
		printf("%s %d\n", temp.plate, temp.km);
	}
}

car_t findMinKM(queue_t *cars)
{
	int	cnt = cars->counter;
	car_t	min, temp;

	min = remove(cars);
	insert(cars, min);

	for (int i = 1; i < cnt; i++)
	{
		temp = remove(cars);
		if (temp.km < min.km)
			min = temp;
		insert(cars, temp);
	}
	return min;
}